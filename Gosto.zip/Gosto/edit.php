<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cattlemanagement";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM Orders WHERE id=$id";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $amount = $_POST['amount'];

    $sql = "UPDATE Orders SET name='$name', phone='$phone', address='$address', amount=$amount WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully!";
        header("Location: admin.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<form method="POST">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
    Name: <input type="text" name="name" value="<?php echo $row['name']; ?>"><br>
    Phone: <input type="text" name="phone" value="<?php echo $row['phone']; ?>"><br>
    Address: <input type="text" name="address" value="<?php echo $row['address']; ?>"><br>
    Amount: <input type="number" name="amount" value="<?php echo $row['amount']; ?>"><br>
    <input type="submit" value="Update">
</form>
