<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cattlemanagement";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$name = $_POST['name'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$amount = $_POST['amount'];

// SQL to insert data
$sql = "INSERT INTO Orders (name, phone, address, amount)
VALUES ('$name', '$phone', '$address', $amount)";

if ($conn->query($sql) === TRUE) {
    echo "Order placed successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
